function askQuestion() {
    var p = prompt('how much wood would a wood chuck chuck if a wood chuck could chuck wood?');
    if (p !=null) {
        document.getElementById
        ('question').innerHTML =
        'damn twin ' + p + ' woods' + ' is a lotta wood';
    }
}